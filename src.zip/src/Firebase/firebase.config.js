const firebaseConfig = {
    apiKey: "AIzaSyBd5Oi5qJXzPIeHkI4_P8tNLP6yEIBVgSY",
    authDomain: "grow-fitness-b6c91.firebaseapp.com",
    projectId: "grow-fitness-b6c91",
    storageBucket: "grow-fitness-b6c91.appspot.com",
    messagingSenderId: "675221656071",
    appId: "1:675221656071:web:c2d9f6a85f0920cd8810a2"
  };
  export default firebaseConfig;